The chatbot unfortunately will not work in Google Collab or Jupyter Notebook.

For the best experience, please try using PyCharm or any standalone IDE you have been using.

To run the program, just open the folder in Pycharm

Make sure everything is imported in each each file:
chatbot.py
neuralnet.py
train.py
process.py
 
If you see that import is highlighted red, hover over the import that is highlighted that, you should see an "Install Package" option.
Once imported, go ahead and run the chatbot.py file.

Terminal Command:

python chatbot.py


Output:

Hey there! Welcome to the Punn-iest bot, Where I tell you the best puns! type (quit) to close and save our session!

What's your name?:

-----------------------

If you see the following output above you should be good to go! Please reach out to me if you have any questions at all. 
